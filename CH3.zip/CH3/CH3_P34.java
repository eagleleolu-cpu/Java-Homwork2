import java.io.BufferedReader; // 匯入此範例需要的 Java 標準類別
import java.io.IOException; // 匯入此範例需要的 Java 標準類別
import java.io.InputStreamReader; // 匯入此範例需要的 Java 標準類別
public class CH3_P34 { // 宣告本投影片範例的主類別
    public static void main(String[] args) throws IOException { // 宣告程式進入點，執行本範例的主要流程
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)); // 建立具緩衝功能的文字輸入讀取器
        System.out.println("請輸入一個整數："); // 把提示訊息或運算結果顯示於主控台
        String input = reader.readLine(); // 讀取使用者輸入的一行文字
        try { // 開始執行可能發生例外的程式區段
            int number = Integer.parseInt(input.trim()); // 將文字轉換成整數以進行後續處理
            System.out.println("您輸入的整數是：" + number); // 把提示訊息或運算結果顯示於主控台
        } catch (NumberFormatException exception) { // 發生指定例外時改以安全訊息回應
            System.out.println("輸入錯誤：需要一個整數。"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
