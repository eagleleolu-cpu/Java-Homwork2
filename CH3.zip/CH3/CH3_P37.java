import java.util.Locale; // 匯入此範例需要的 Java 標準類別
import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH3_P37 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        System.out.println("請輸入英文字母："); // 把提示訊息或運算結果顯示於主控台
        String text = scanner.nextLine(); // 從鍵盤讀取完整一行文字
        String upper = text.toUpperCase(Locale.ROOT); // 將英文字母轉換為大寫形式
        String lower = text.toLowerCase(Locale.ROOT); // 將英文字母轉換為小寫形式
        System.out.println("轉換成大寫時為" + upper); // 把提示訊息或運算結果顯示於主控台
        System.out.println("轉換成小寫時為" + lower); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
