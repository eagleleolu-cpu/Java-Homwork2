public class CH3_P28 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Car first = new Car(); // 宣告 Car 參考變數，指向建立的物件
        first.show(); // 呼叫指定物件或類別的方法，處理相關資料
        Car second = new Car(1234, 25.0); // 宣告 Car 參考變數，指向建立的物件
        second.show(); // 呼叫指定物件或類別的方法，處理相關資料
    } // 結束目前程式區塊，回到上一層流程
    static class Car { // 建立內部 Car 類別，示範物件導向設計
        private int number; // 宣告私有欄位，防止外部直接修改資料
        private double gasoline; // 宣告私有欄位，防止外部直接修改資料
        Car() { // 建立 Car 建構式，用於初始化物件
            this.number = 0; // 將傳入的新資料儲存到物件欄位
            this.gasoline = 0.0; // 將傳入的新資料儲存到物件欄位
            System.out.println("生產了車子"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
        Car(int newNumber, double newGasoline) { // 建立 Car 建構式，用於初始化物件
            this(); // 由目前建構式呼叫同類別其他建構式
            this.number = newNumber; // 將傳入的新資料儲存到物件欄位
            this.gasoline = newGasoline; // 將傳入的新資料儲存到物件欄位
            System.out.println("完成指定車號與汽油量的初始化"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
        void show() { // 宣告操作物件資料的方法
            System.out.println("車號是" + number + "，汽油量是" + gasoline); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
