public class CH3_P49 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        int number = 1234; // 宣告數值變數，儲存計算資料或欄位值
        Car car = new Car(); // 宣告 Car 參考變數，指向建立的物件
        car.setNumber(number); // 呼叫指定物件或類別的方法，處理相關資料
        changePrimitive(number); // 執行此處資料設定或運算敘述
        System.out.println("呼叫後原始整數：" + number); // 把提示訊息或運算結果顯示於主控台
        changeObject(car); // 執行此處資料設定或運算敘述
        System.out.println("呼叫後物件欄位：" + car.getNumber()); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
    static void changePrimitive(int value) { // 宣告供類別呼叫的靜態方法
        value = 9999; // 執行此處資料設定或運算敘述
        System.out.println("方法內整數副本：" + value); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
    static void changeObject(Car target) { // 宣告供類別呼叫的靜態方法
        target.setNumber(5678); // 呼叫指定物件或類別的方法，處理相關資料
    } // 結束目前程式區塊，回到上一層流程
    static class Car { // 建立內部 Car 類別，示範物件導向設計
        private int number; // 宣告私有欄位，防止外部直接修改資料
        void setNumber(int newNumber) { // 宣告操作物件資料的方法
            this.number = newNumber; // 將傳入的新資料儲存到物件欄位
        } // 結束目前程式區塊，回到上一層流程
        int getNumber() { // 宣告回傳指定欄位數值的取值方法
            return number; // 回傳指定結果，並結束目前的方法
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
