public class CH3_P36 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        String text = "Hello"; // 宣告字串變數，儲存使用者資料或運算結果
        if (text.length() >= 2) { // 檢查指定條件成立與否，決定是否執行區塊
            char first = text.charAt(0); // 取得字串內指定索引的字元
            char second = text.charAt(1); // 取得字串內指定索引的字元
            System.out.println(text + "的第一個字元是" + first); // 把提示訊息或運算結果顯示於主控台
            System.out.println(text + "的第二個字元是" + second); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
        System.out.println(text + "的長度是" + text.length()); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
