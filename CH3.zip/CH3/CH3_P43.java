import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH3_P43 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        System.out.println("請輸入兩個整數："); // 把提示訊息或運算結果顯示於主控台
        if (!scanner.hasNextInt()) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("第一個值不是整數。"); // 把提示訊息或運算結果顯示於主控台
            return; // 提前結束方法，避免不合法的資料繼續運算
        } // 結束目前程式區塊，回到上一層流程
        int first = scanner.nextInt(); // 從鍵盤讀取一個整數作為輸入資料
        if (!scanner.hasNextInt()) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("第二個值不是整數。"); // 把提示訊息或運算結果顯示於主控台
            return; // 提前結束方法，避免不合法的資料繼續運算
        } // 結束目前程式區塊，回到上一層流程
        int second = scanner.nextInt(); // 從鍵盤讀取一個整數作為輸入資料
        int largest = Math.max(first, second); // 取得兩個數字之中較大的數值
        System.out.println(first + " 和 " + second + " 中較大的是 " + largest); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
