public class CH3_P16 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Car car = new Car(1234, 20.5); // 宣告 Car 參考變數，指向建立的物件
        int number = car.getNum(); // 宣告數值變數，儲存計算資料或欄位值
        double gasoline = car.getGas(); // 宣告數值變數，儲存計算資料或欄位值
        System.out.println("讀取到車號：" + number); // 把提示訊息或運算結果顯示於主控台
        System.out.println("讀取到汽油量：" + gasoline); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
    static class Car { // 建立內部 Car 類別，示範物件導向設計
        private final int number; // 宣告建構後不可重新指定的私有欄位
        private final double gasoline; // 宣告建構後不可重新指定的私有欄位
        Car(int newNumber, double newGasoline) { // 建立 Car 建構式，用於初始化物件
            this.number = newNumber; // 將傳入的新資料儲存到物件欄位
            this.gasoline = newGasoline; // 將傳入的新資料儲存到物件欄位
        } // 結束目前程式區塊，回到上一層流程
        int getNum() { // 宣告回傳指定欄位數值的取值方法
            return number; // 回傳指定結果，並結束目前的方法
        } // 結束目前程式區塊，回到上一層流程
        double getGas() { // 宣告回傳指定欄位數值的取值方法
            return gasoline; // 回傳指定結果，並結束目前的方法
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
