public class CH3_P31 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Car.showCount(); // 呼叫指定物件或類別的方法，處理相關資料
        Car first = new Car(1234, 20.5); // 宣告 Car 參考變數，指向建立的物件
        first.show(); // 呼叫指定物件或類別的方法，處理相關資料
        Car.showCount(); // 呼叫指定物件或類別的方法，處理相關資料
        Car second = new Car(4567, 30.5); // 宣告 Car 參考變數，指向建立的物件
        second.show(); // 呼叫指定物件或類別的方法，處理相關資料
        Car.showCount(); // 呼叫指定物件或類別的方法，處理相關資料
    } // 結束目前程式區塊，回到上一層流程
    static class Car { // 建立內部 Car 類別，示範物件導向設計
        private static int count = 0; // 宣告所有物件共同使用的私有靜態欄位
        private final int number; // 宣告建構後不可重新指定的私有欄位
        private final double gasoline; // 宣告建構後不可重新指定的私有欄位
        Car(int newNumber, double newGasoline) { // 建立 Car 建構式，用於初始化物件
            this.number = newNumber; // 將傳入的新資料儲存到物件欄位
            this.gasoline = newGasoline; // 將傳入的新資料儲存到物件欄位
            count++; // 將計數值增加一，推進處理進度
        } // 結束目前程式區塊，回到上一層流程
        static void showCount() { // 宣告供類別呼叫的靜態方法
            System.out.println("目前生產車子數量：" + count); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
        void show() { // 宣告操作物件資料的方法
            System.out.println("車號是" + number + "，汽油量是" + gasoline); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
