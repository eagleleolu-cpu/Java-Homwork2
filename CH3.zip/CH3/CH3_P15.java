public class CH3_P15 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Car car = new Car(); // 宣告 Car 參考變數，指向建立的物件
        int number = 1234; // 宣告數值變數，儲存計算資料或欄位值
        double gasoline = 20.5; // 宣告數值變數，儲存計算資料或欄位值
        car.setCar(number, gasoline); // 呼叫指定物件或類別的方法，處理相關資料
        car.show(); // 呼叫指定物件或類別的方法，處理相關資料
    } // 結束目前程式區塊，回到上一層流程
    static class Car { // 建立內部 Car 類別，示範物件導向設計
        private int number; // 宣告私有欄位，防止外部直接修改資料
        private double gasoline; // 宣告私有欄位，防止外部直接修改資料
        void setCar(int newNumber, double newGasoline) { // 宣告操作物件資料的方法
            this.number = newNumber; // 將傳入的新資料儲存到物件欄位
            this.gasoline = newGasoline; // 將傳入的新資料儲存到物件欄位
        } // 結束目前程式區塊，回到上一層流程
        void show() { // 宣告操作物件資料的方法
            System.out.println("車號是" + number + "，汽油量是" + gasoline); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
