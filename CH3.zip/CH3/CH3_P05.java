public class CH3_P05 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Car car = new Car(); // 宣告 Car 參考變數，指向建立的物件
        System.out.println("已建立 Car 物件：" + (car != null)); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
    static class Car { // 建立內部 Car 類別，示範物件導向設計
        int number; // 宣告數值變數，儲存計算資料或欄位值
        double gasoline; // 宣告數值變數，儲存計算資料或欄位值
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
