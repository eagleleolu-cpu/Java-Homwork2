import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH3_P40 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        System.out.println("請輸入第一段文字："); // 把提示訊息或運算結果顯示於主控台
        String first = scanner.nextLine(); // 從鍵盤讀取完整一行文字
        System.out.println("請輸入第二段文字："); // 把提示訊息或運算結果顯示於主控台
        String second = scanner.nextLine(); // 從鍵盤讀取完整一行文字
        StringBuffer buffer = new StringBuffer(first); // 建立可修改內容的字串緩衝物件
        buffer.append(second); // 將第二段文字附加到可變字串的尾端
        System.out.println("連接後的文字是：" + buffer.toString()); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
