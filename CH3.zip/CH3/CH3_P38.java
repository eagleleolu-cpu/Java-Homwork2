import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH3_P38 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        System.out.println("請輸入文字："); // 把提示訊息或運算結果顯示於主控台
        String text = scanner.nextLine(); // 從鍵盤讀取完整一行文字
        System.out.println("請輸入要搜尋的字元："); // 把提示訊息或運算結果顯示於主控台
        String input = scanner.nextLine(); // 從鍵盤讀取完整一行文字
        if (input.isEmpty()) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("搜尋字元不可為空。"); // 把提示訊息或運算結果顯示於主控台
            return; // 提前結束方法，避免不合法的資料繼續運算
        } // 結束目前程式區塊，回到上一層流程
        char target = input.charAt(0); // 取得字串內指定索引的字元
        int index = text.indexOf(target); // 搜尋目標字元第一次出現的索引位置
        if (index >= 0) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("在索引 " + index + " 找到字元「" + target + "」。"); // 把提示訊息或運算結果顯示於主控台
        } else { // 處理前述條件不成立時的分支
            System.out.println("在文字中找不到「" + target + "」。"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
