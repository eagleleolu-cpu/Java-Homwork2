public class CH2_P49 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        int[][] scores = {{80, 60, 22, 50, 75}, {90, 55, 68, 72, 58}}; // 宣告並初始化儲存資料的陣列
        for (int group = 0; group < scores.length; group++) { // 設定迴圈初始值、執行條件與每輪更新方式
            for (int index = 0; index < scores[group].length; index++) { // 設定迴圈初始值、執行條件與每輪更新方式
                System.out.println("第" + (group + 1) + "組第" + (index + 1) + "個人的分數是" + scores[group][index] + "分"); // 把提示訊息或運算結果顯示於主控台
            } // 結束目前程式區塊，回到上一層流程
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
