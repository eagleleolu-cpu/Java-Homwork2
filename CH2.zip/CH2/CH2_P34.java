import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH2_P34 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        System.out.println("請問要跳過第幾次迴圈？請輸入 1 到 10："); // 把提示訊息或運算結果顯示於主控台
        if (!scanner.hasNextInt()) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("請輸入合法的整數。"); // 把提示訊息或運算結果顯示於主控台
            return; // 提前結束方法，避免不合法的資料繼續運算
        } // 結束目前程式區塊，回到上一層流程
        int skipAt = scanner.nextInt(); // 從鍵盤讀取一個整數作為輸入資料
        if (skipAt < 1 || skipAt > 10) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("請輸入 1 到 10 之間的整數。"); // 把提示訊息或運算結果顯示於主控台
            return; // 提前結束方法，避免不合法的資料繼續運算
        } // 結束目前程式區塊，回到上一層流程
        for (int count = 1; count <= 10; count++) { // 設定迴圈初始值、執行條件與每輪更新方式
            if (count == skipAt) { // 檢查指定條件成立與否，決定是否執行區塊
                continue; // 跳過目前迴圈剩餘內容並開始下一輪
            } // 結束目前程式區塊，回到上一層流程
            System.out.println("第" + count + "次的迴圈"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
