import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH2_P45 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        int[] scores = new int[5]; // 宣告並初始化儲存資料的陣列
        System.out.println("請輸入 5 個人的分數："); // 把提示訊息或運算結果顯示於主控台
        for (int index = 0; index < scores.length; index++) { // 設定迴圈初始值、執行條件與每輪更新方式
            if (!scanner.hasNextInt()) { // 檢查指定條件成立與否，決定是否執行區塊
                System.out.println("輸入錯誤：每一筆都必須是整數。"); // 把提示訊息或運算結果顯示於主控台
                return; // 提前結束方法，避免不合法的資料繼續運算
            } // 結束目前程式區塊，回到上一層流程
            scores[index] = scanner.nextInt(); // 從鍵盤讀取一個整數作為輸入資料
        } // 結束目前程式區塊，回到上一層流程
        for (int pass = 0; pass < scores.length - 1; pass++) { // 設定迴圈初始值、執行條件與每輪更新方式
            boolean swapped = false; // 建立布林旗標，記錄判斷結果
            for (int index = 0; index < scores.length - 1 - pass; index++) { // 設定迴圈初始值、執行條件與每輪更新方式
                if (scores[index] > scores[index + 1]) { // 檢查指定條件成立與否，決定是否執行區塊
                    int temporary = scores[index]; // 宣告數值變數，儲存計算資料或欄位值
                    scores[index] = scores[index + 1]; // 讀寫陣列中指定索引位置的資料
                    scores[index + 1] = temporary; // 讀寫陣列中指定索引位置的資料
                    swapped = true; // 執行此處資料設定或運算敘述
                } // 結束目前程式區塊，回到上一層流程
            } // 結束目前程式區塊，回到上一層流程
            if (!swapped) { // 檢查指定條件成立與否，決定是否執行區塊
                break; // 立即離開目前的 switch 或迴圈
            } // 結束目前程式區塊，回到上一層流程
        } // 結束目前程式區塊，回到上一層流程
        for (int index = 0; index < scores.length; index++) { // 設定迴圈初始值、執行條件與每輪更新方式
            System.out.println("第" + (index + 1) + "名的分數是" + scores[index]); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
