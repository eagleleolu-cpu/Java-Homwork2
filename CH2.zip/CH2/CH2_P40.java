import java.lang.reflect.Array; // 匯入此範例需要的 Java 標準類別
public class CH2_P40 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        int[] numbers = (int[]) Array.newInstance(int.class, 3); // 透過反射方法建立指定型態的陣列
        Array.setInt(numbers, 0, 123); // 以反射 API 設定陣列指定索引處的整數
        Array.setInt(numbers, 1, 456); // 以反射 API 設定陣列指定索引處的整數
        Array.setInt(numbers, 2, 789); // 以反射 API 設定陣列指定索引處的整數
        for (int index = 0; index < numbers.length; index++) { // 設定迴圈初始值、執行條件與每輪更新方式
            System.out.println("intArray[" + index + "] = " + Array.getInt(numbers, index)); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
