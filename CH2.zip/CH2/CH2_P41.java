public class CH2_P41 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        int[] scores = {80, 60, 22, 50, 75}; // 宣告並初始化儲存資料的陣列
        int requestedIndex = 10; // 宣告數值變數，儲存計算資料或欄位值
        if (requestedIndex >= 0 && requestedIndex < scores.length) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("指定分數：" + scores[requestedIndex]); // 把提示訊息或運算結果顯示於主控台
        } else { // 處理前述條件不成立時的分支
            System.out.println("索引 " + requestedIndex + " 超出陣列範圍，已安全略過。"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
        for (int index = 0; index < scores.length; index++) { // 設定迴圈初始值、執行條件與每輪更新方式
            System.out.println("第" + (index + 1) + "個人的分數是" + scores[index] + "分"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
