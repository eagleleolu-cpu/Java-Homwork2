public class CH2_P26 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        int count = 1; // 宣告數值變數，儲存計算資料或欄位值
        while (count <= 5) { // 條件成立時繼續重複執行迴圈
            System.out.println("第" + count + "次的迴圈"); // 把提示訊息或運算結果顯示於主控台
            count++; // 將計數值增加一，推進處理進度
        } // 結束目前程式區塊，回到上一層流程
        System.out.println("迴圈結束"); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
