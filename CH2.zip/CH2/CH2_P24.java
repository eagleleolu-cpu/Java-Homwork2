public class CH2_P24 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        for (int count = 1; count <= 5; count++) { // 設定迴圈初始值、執行條件與每輪更新方式
            System.out.println("第" + count + "次的迴圈"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
        System.out.println("迴圈結束"); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
