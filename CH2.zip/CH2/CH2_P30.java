public class CH2_P30 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        for (int row = 0; row < 5; row++) { // 設定迴圈初始值、執行條件與每輪更新方式
            for (int column = 0; column < 3; column++) { // 設定迴圈初始值、執行條件與每輪更新方式
                System.out.println("迴圈" + row + "，子迴圈" + column); // 把提示訊息或運算結果顯示於主控台
            } // 結束目前程式區塊，回到上一層流程
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
