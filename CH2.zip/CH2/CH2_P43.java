public class CH2_P43 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        int[] scores = {80, 60, 22, 50, 75}; // 宣告並初始化儲存資料的陣列
        for (int index = 0; index < scores.length; index++) { // 設定迴圈初始值、執行條件與每輪更新方式
            System.out.println("第" + (index + 1) + "個人的分數是" + scores[index] + "分"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
        System.out.println("考試人數為" + scores.length + "人"); // 把提示訊息或運算結果顯示於主控台
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
