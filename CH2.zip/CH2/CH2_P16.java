import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH2_P16 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        System.out.println("請輸入 A 或 B："); // 把提示訊息或運算結果顯示於主控台
        String input = scanner.nextLine().trim(); // 從鍵盤讀取完整一行文字
        if (input.isEmpty()) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("不可輸入空白內容。"); // 把提示訊息或運算結果顯示於主控台
            return; // 提前結束方法，避免不合法的資料繼續運算
        } // 結束目前程式區塊，回到上一層流程
        char letter = Character.toUpperCase(input.charAt(0)); // 取得字串內指定索引的字元
        switch (letter) { // 根據運算結果選擇對應的 case 分支
            case 'A': // 指定可處理的選項值
                System.out.println("輸入的是 A"); // 把提示訊息或運算結果顯示於主控台
                break; // 立即離開目前的 switch 或迴圈
            case 'B': // 指定可處理的選項值
                System.out.println("輸入的是 B"); // 把提示訊息或運算結果顯示於主控台
                break; // 立即離開目前的 switch 或迴圈
            default: // 處理未符合任何列舉選項的情形
                System.out.println("請輸入 A 或 B"); // 把提示訊息或運算結果顯示於主控台
                break; // 立即離開目前的 switch 或迴圈
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
