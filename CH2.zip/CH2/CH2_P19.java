import java.util.Scanner; // 匯入此範例需要的 Java 標準類別
public class CH2_P19 { // 宣告本投影片範例的主類別
    public static void main(String[] args) { // 宣告程式進入點，執行本範例的主要流程
        Scanner scanner = new Scanner(System.in); // 建立 Scanner 物件，準備讀取鍵盤輸入
        System.out.println("請問你是男生嗎？請輸入 Y 或 N："); // 把提示訊息或運算結果顯示於主控台
        String answer = scanner.nextLine().trim(); // 從鍵盤讀取完整一行文字
        if (answer.equalsIgnoreCase("Y")) { // 檢查指定條件成立與否，決定是否執行區塊
            System.out.println("你是男生啊！"); // 把提示訊息或運算結果顯示於主控台
        } else if (answer.equalsIgnoreCase("N")) { // 前一條件不成立時，再檢查下一個條件
            System.out.println("你是女生啊！"); // 把提示訊息或運算結果顯示於主控台
        } else { // 處理前述條件不成立時的分支
            System.out.println("請輸入 Y 或 N"); // 把提示訊息或運算結果顯示於主控台
        } // 結束目前程式區塊，回到上一層流程
    } // 結束目前程式區塊，回到上一層流程
} // 結束目前程式區塊，回到上一層流程
